# Sprint 1 Report (1/14/2023 - 2/2/2023)

sprint demo link - https://youtu.be/s4r9p8Bvpxc

## What's New (User Facing)
 * Updated Radar Plot to better fit clients wishes. Waiting to hear back from more detail before changing anything else.
 * Fixed positioning of text boxes and updated code on bar graphs to input real data instead of hard coded data.
 * Overall look of pdf has been changed to look more professional and closer to our final deliverable

## Work Summary (Developer Facing)
The radar plot has been updated to better fit the client's requirements and further changes are pending feedback. The positioning of text boxes has been fixed and the code for bar graphs updated to use real data instead of hard-coded data. The overall appearance of the PDF has been improved to look more professional and closer to the final deliverable. We also had a meeting with Walt and the mobile app team to discuss future plans, if time permits. We also had separate meetings with the mobile team to discuss any shared compnenets we could implement together, to save time and resources.

## Unfinished Work
* As mentioned earlier, our radar plot isnt fully finished. The data still only accepts hard data and doesnt have vector functionality yet. We've mentioned this to our client and he is going to come up with a better description for us to go off of since there was confusion on what was needed for the radar plot, so we are waiting on Walt to send that to us before we can continue on this.
* Similarly, our client is going to send us an example dataset of what a finished survey would look like so we can use that data to test all of our graph and textbox functionalities. Therefore, testing with real data is another thing we are waiting on since we had our meeting discussing this request on Monday (January 30th).
* GCP implementation hasnt been looked at yet since we had to clear up some questions and concerns on our Monday (January 30th) meeting.

## Completed Issues/User Stories
Here are links to the issues that we completed in this sprint:

 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/43>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/44>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/45>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/46>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/47>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/48>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/49>
 * <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/50>
 
 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
* <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/10>
* <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/15>
* <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/22>
* <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/37>
* <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/38>
* <https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/51>

For issue 10, our readme will constantly be updated throughout the rest of the project as new documentation is released, so always a work in progress.

For issue 15, we aren't fully sure we will need this issue anymore since we are going to be recieving data from our client, but worth holding onto for now incase we need some extra data options.

For issue 22, our updates on this issue are dependent on issue 37 since they are related, so once issue 37 is worked on more this will simultaneously be completed.

For issue 37, we haven't found the best way to automate data being put into the database, we have focused mostly on the code for now and hope to look into this part soon when our code is more advanced.

For issue 38, we are constantly developing python code, so this will likely not be finished until our code is completed in full.

For issue 51, we thought about this last sprint that through our development things have gotten messy, so we want to change the file structure to be cleaner.

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/automated_responses.py)
 * [data_report](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/data_report.py)
 
## Retrospective Summary
Here's what went well:
  *  Worked well together as a team.
  *  Made progress on our new direction for the project
  *  Communicated with client well.
  *  Had many team meetings
 
Here's what we'd like to improve:
   * Tracking issues better.
   * Starting work early in the sprint
  
Here are changes we plan to implement in the next sprint:
   * Add more code and refine our code.
   * Meet more often.

