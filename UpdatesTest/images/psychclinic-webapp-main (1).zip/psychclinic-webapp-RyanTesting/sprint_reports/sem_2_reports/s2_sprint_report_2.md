# Sprint 2 Report (2/3/23 - 3/2/2023)

Youtube link for demo - https://youtu.be/zEqX9d_fNSM

## What's New (User Facing)
 * Comparison Figure on last page of pdf.
 * Code refactoring from one file to three.
 * Standard Morals bar graphs and descriptions.
 * Titles added to graphs and legend removed.
 * New data/vectors and knowledge of radar plot

## Work Summary (Developer Facing)
More work has been completed on the pdf generation. Graphs and text boxes for the Moral Standards of the survey data has been added along with the original goals graphs and text boxes. Titles were also added to the graphs and the legend was removed to fix formatting. The comparison page has been added which can be seen on the last page of the pdf. 

## Unfinished Work
The radar plot has not been finished because data and information about the construction of the radar plot was recently received. This should be further worked on soon after the completion of this sprint, which involves further implementation of the correct data and new implementation of vector values calculated from the qualtrics survey flow. Bar Graphs are not fully completed. Almost all of them have been implemented, however, there are just a few more to complete which should be relatively easy to implement. The database has not been set up as we are still doing research and once that is implemented we can also work on data importation and usage in the graphs, however, we have designed the functions to be entirely ready for when the data is added.

## Completed Issues/User Stories
Here are links to the issues that we completed in this sprint:

 * [URL of issue 1](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/51)
 * [URL of issue 2](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/52)
 * [URL of issue 3](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/53)
 * [URL of issue 4](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/55)
 * [URL of issue 5](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/56)
 * [URL of issue 6](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/58)
 * [URL of issue 7](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/59)
 
 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
 * [URL of issue 1](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/10): This will continue to be updated throughout the project.
 * [URL of issue 2](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/15): This will continue to be updated throughout the project.
 * [URL of issue 3](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/22): Still continuing to do research before we can implement the database.
 * [URL of issue 4](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/37): Won't be finished until database is set up.
 * [URL of issue 5](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/38): Not finished yet, however, a lot of progress was made.
 * [URL of issue 6](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/54): More information of radar plot generation was discovered this sprint.

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [Data Report](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/data_report.py)
 * [Report Generator](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/Report_Generator.py)
 * [PDF Generator](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/PDF_Generator.py)
 * [Graph Generator](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/Graph_Generator.py)
 * [Automated Responses](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/automated_responses.py)
 
## Retrospective Summary
Here's what went well:
  * Creation of functions has gone well.
  * Working together as a team.
  * Everybody gets along and is on the same page generally.
  * Working through busy schedules.
 
Here's what we'd like to improve:
   * Better communication between teammates and also with client.
   * More efficent work and better planning of tasks to be completed.
   * Fast starts on tasks.
  
Here are changes we plan to implement in the next sprint:
   * Continue to communicate with client even better as we fine tune our project.
   * Continue meeting frequently and working together to complete tasks efficiently.
   * Add issues earlier to make it easier to assign to group members.
