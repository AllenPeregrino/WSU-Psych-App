# Sprint 3 Report (3/3/23 - 4/2/2023)

video link - https://youtu.be/csUcp4kwc7A

## What's New (User Facing)
 * New bar graphs added for self-esteem and etc.
 * Bar graph added to show temperament stats.
 * Radar plot updated to look as intended by client.
 * Code developed for grabbing data from CSV. This will be pruned and used to run functions to generate the graphs.

## Work Summary (Developer Facing)
The PDF generation is almost completely finished. All the functions to generate the graphs have been completed and now the data grabbing just needs to be automated which should be completed within the next week. We have code that, with the help of a Qualtrics API, grabs the data from Qualtrics and our new code to create a pandas dataframe allows for us to access the newest set of data exremely easy. All the graphs have been completed and general layout of the PDF has been worked on. We are now awaiting final inputs on the general layout for the PDF from our client so that we can have the PDF looking exactly as he wants.


## Unfinished Work
We must finish the automatic pruning of the data and then the calling of functions with the data. This will be relatively simple because we know the format to set the data in and have designed the graph generation functions so that it will be easy. Need to finish implementation into GCP and set up the ping on Qualtrics to have our code run using Cloud Run.

## Completed Issues/User Stories
Here are links to the issues that we completed in this sprint:

 * [URL of issue 1](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/60)
 * [URL of issue 2](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/61)
 * [URL of issue 3](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/62)
 * [URL of issue 4](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/63)
 * [URL of issue 5](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/64)
 * [URL of issue 6](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/54)
 * [URL of issue 7](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/54)
 * [URL of issue 8](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/67)
 * [URL of issue 9](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/68)
 * [URL of issue 10](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/38)
 
 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
 * [URL of issue 1](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/10): This will continue to be updated throughout the project.
 * [URL of issue 2](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/15): This will continue to be updated throughout the project.
 * [URL of issue 3](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/22): Still continuing to do research before we can implement the database.
 * [URL of issue 4](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/37): Won't be finished until database is set up.

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [Report Generator](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/Report_Generator.py)
 * [PDF Generator](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/PDF_Generator.py)
 * [Graph Generator](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/Graph_Generator.py)
 * [Automated Responses](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/automated_responses.py)
 
 
## Retrospective Summary
Here's what went well:
  * Working together as a team.
  * Everybody gets along and is on the same page.
  * Working through busy schedules.
 
Here's what we'd like to improve:
   * Better communication with client.
   * More efficent work and better planning of tasks to be completed.
   * Start tasks earlier so that discussions can be had about the plan of attack.
  
Here are changes we plan to implement in the next sprint:
   * Continue to communicate with client even better as we fine tune our project.
   * Continue meeting frequently and working together to complete tasks efficiently.
   * Add issues earlier to make it easier to assign to group members.
