# Sprint 2 Report (8/26/21 - 9/24/2021)

## Sprint 2 demo

https://youtu.be/U5kUnclVOvA

## What's New (User Facing)
 * Update to survey variables and calculations after submission
 * Goals Textboxes to survey results
 * Goals Graphs added to survey results

## Work Summary (Developer Facing)
During Sprint 2, the team was able to have meetings with the client to further dicuss what we have been working on and for more clarification on what needs to be completed. Team Bluebirds also conducted a meeting with the mobile app group for the same client, and have discussed how our project could benefit theirs. We completed a document regarding our testing and acceptance plans and how we will go about testing the project and all the pieces individually and as a whole. We began working more in depth in Qualtrics to implement the survey results requested by the client, and are working to create the graphs and figures that are needed. This was delayed slightly by us not having the data elements that are needed to create the graphs, but after meeting with the client we were able to get some of the information. We had some scheduling conflicts as a group, but continued to find times to meet with each other.

## Unfinished Work
Qualtrics Graphs:
We are still working out all the graphs and figures that can be created in the Qualtrics survey itself because of a delay that caused the team to not have the specific variables that would be used in the graphs(all the variables had complex names that did not necessarily describe what they should be used for). Although we have made progress when it comes to developing the desired results page, there is still much work that needs to be done. Qualtrics is a very complicated environment to work in and it can be difficult to create the output we are trying to create.
JavaScript Code:
As we have talked about in previous documents, whatever graphs and figures that can not be developed directly in Qualtrics will need to be created through our own code. Qualtrics is able to work with JavaScript so once we finish creating all the graphs that we can in Qualtrics we will need to see which ones are left to make and have those developed in JavaScript and then shown in the results.
Database Storage:
With the meeting for the mobile app group, we have a new piece that needs to be implemented into our system. Once the user finished the survey, they will be presented with the results in visual forms, but not we also need to implement a way for the raw data to be stored into the database created by the other team. This will require communication with the other team to allow us access to their database potentially so we will need to stay in contact with them. This work has not yet been completed.

## Completed Issues/User Stories
Here are links to the issues that we completed in this sprint:

 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/12
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/13
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/14
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/16
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/17
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/23
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/24

 
 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/15
 This issue will not be completed until the project is finished and final tests are finished
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/20
 Not finished yet because this will require more time. There have been delays from client travels and so the finished results page can not be completed yet. Not all of
 the variables in the dataset have been produced yet.
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/21
 Once the results page mentioned in issue 20 is completed, we can begin development of the JavaScript code. Client has requested for as much of the work to be
 completed within Qualtrics as possible, and so we will not start JavaScript code until after confirmation we need it.
 * https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/22
 This issue has not been completed because we need to be contacted by the mobile group regarding how they would like to be sent to data from the survey.

## Code Files for Review

We currently have no code to include. We are working to build all features within qualtrics as requested by client. If code is requiored, it will be to cover a feature not present in qualtrics.
 
## Retrospective Summary
Here's what went well:
  * Team communicated effectively.
  * Documents were completed to an acceptable level.
 
Here's what we'd like to improve:
   * Meeting more often and ahead of when we need to.
   * Work be completed sooner and potentially in more depth/higher quality.
   * Make up for lost week at the beginning of the semester
  
Here are changes we plan to implement in the next sprint:
   * Set a week in advance for when we can meet since schedules are getting so busy.
   * Distribute workloads ahead of time so that everybody is on the same page to get things done on time.
   * Catch up for our lost week in Sprint 1 due to delays.
