# Sprint 3 Report (11/16/22 - 12/9/22)

## Sprint 3 demo

https://youtu.be/HD91hIP-fsk

## What's New (User Facing)
 * Python code for exporting results data from Qualtrics using an API.
 * Beginning of Python code to develop PDF file that will store the graphs created.
 * Working on setting up the database.
 * Working on python code for creating the graphs/figures

## Work Summary (Developer Facing)

This sprint was extremely important for our team moving forward. We did a lot of testing on Qualtrics and our methods for display the results report back to the user.
After doing several tests we came across a problem of security. We contacted Qualtrics support and asked them if there were ways to make our method more secure 
and they informed us it was not possible because participants would be able to adjust the filters that are used to grab their results and it would allow them to see
others' results even though they would not have admin access to the survey. This means that we need to fallback on our other plans to send the results to our database
and then create then graphs and figures using python and then have the results sent back to the participant. This was only possible to discover because of our testing
and luckily we were able to discover the issue so that there were no breaches in confidentiality.

We also began heavy work on the database and the pdf generation. The database was not our deliverable initially, but was picked up to help support the mobile group.
The pdf generation is also now necessary after the problems we had and how we must use python to create the graphs and we believed that pdf form would be the best method for displaying back to the participants of the survey.

## Unfinished Work
We were able to begin the operations for automated the sending of survey results to the database in CSV file format. We have designed a workflow within Qualtrics that will automatically do this once a survey is submitted. This has not yet been finished because we need to finish setting up the database first. The graphs/figures using the data needs to be finished. We did a lot of good work on getting the graphs created and we can successfully create bar graphs, horizontal and vertical, and radar plots. These can also be added to our pdf that we will display to the user. We will need to finish the remaining graphs and then work on format. The last part we need to finish is just automating the entire process so that when the workflow from Qualtrics runs all of the work is done and then displayed to the user.

## Completed Issues/User Stories
Here are links to the issues that we completed in this sprint:

 * [URL of issue 20](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/20)
 * [URL of issue 21](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/21)
 * [URL of issue 26](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/26)
 * [URL of issue 27](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/27)
 * [URL of issue 28](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/28)
 * [URL of issue 29](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/29)
 * [URL of issue 30](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/30)
 * [URL of issue 31](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/31)
 * [URL of issue 32](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/32)
 * [URL of issue 33](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/33)
 * [URL of issue 34](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/34)
 * [URL of issue 35](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/35)
 * [URL of issue 36](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/36)
 * [URL of issue 39](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/39)
 * [URL of issue 40](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/40)

 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
 * [URL of issue 10](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/10)
This issue was not completed because it is something that will always be updating as we work on this project so it will never be "complete"
 * [URL of issue 15](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/15)
This issues will not be "complete" until the completion of the project
 * [URL of issue 22](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/22)
This issue will be completed next semester
 * [URL of issue 37](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/37)
This issue will be completed next semester
 * [URL of issue 38](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/38)
This issue will be completed next semester

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [automated_responses](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/automated_responses.py)
 * [data_report](https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/QualtricsAPI/Code/wsu_report_generator_2.0/data_report.py)
 
## Retrospective Summary
Here's what went well:
  * Worked well together as a team.
  * Made great progress in the exporting of data to the database and pdf generation.
  * Documents up to standards.
  * Testing proved to be effective.
  * Creative with our problem solving.
 
Here's what we'd like to improve:
   * Communication between teammates and clients.
   * Getting ahead on work.
   * Tracking issues better.
  
Here are changes we plan to implement in the next sprint:
   * Set up weekly meeting times ahead of schedule for client and team meetings so that we can have clearer schedules.
   * More development in coding which will be possible now that we have more options.
