# Sprint x Report (8/26/21 - 9/24/2021)

## App Demo

https://youtu.be/ZewY1PKrrnM

Here is a link to our app demo that goes over our documents, survey, and other things we accomplished this sprint.

## What's New (User Facing)
- Feature 1: New Workflow Added
Added a workflow to the Qualtrics survey that will be used to test how Qualtrics can automatically run our code at the survey.
- Bug 1: New Workflow (not fixed but documenting)
The workflow has not been implemented properly to run the code that will create the graphs and figures and show them to participants. This will be fixed in the future and the workflow will function by running our code when the survey is finished and printing the graph back to the participant.

## Work Summary (Developer Facing)

Our team's accomplishmnets are almost primarily centered around the consultation and documented aspects of the overall project. We were wanting to make sure we first nailed that part down well before jumping into design development or code creation to give ourselves a good foundation. For this to be accomplished, it meant multiple meetings with our sponsors discussing different topics such as architecture design, use cases, system requirements, and all other things befitting to the theme. Additionally, there was extra consultation required outside of the required meetings that we needed for us to fully understand the complexity and size of the Qualtrics Survey, and their current R program. One major barrier we had to overcome was figure out exactly how to go about this problem. The ask was quite vague for us so there was research required before even beginning the development process. All we knew was to essentially recreate the R program in a more automated process. This was tough because our sponsors didn't have too much input or guidance for us, just a few specifications like reusability, and correctness. Other than that, Walt and Aninda were relaxed for the rest of it so we had to figure that out ourselves, which was defeinitely our biggest barrier. Fortunetly, we found that Qualtrics has more integrations for our project than we originally anticipated, which is what we are going to be exploring more in depth for Sprint 2. 

## Unfinished Work

We completed all our work for this sprint so there's nothing for this section.

## Completed Issues/User Stories
Here are links to the issues that we completed in this sprint:

Issue 1: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/1
Issue 2: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/2
Issue 3: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/3
Issue 4: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/4
Issue 5: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/5
Issue 6: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/6
Issue 7: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/7

We added a new branch for Documents so we can edit them in that branch, then merge onto main when everything is working correctly.
 
 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
Issue 8: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/8
 - Unfinished because we will check it off once wse finish this document in it's entirety

Issue 9: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/9
 - We haven't found a time yet to meet with Walt and Aninda, plan to sometime the week of Oct. 17th

Issue 10: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/issues/10
 - Some additional progress to the README.md file is needed. Up to date for this sprint, but more will be added later

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * R Code developed by Aninda Roy: https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/main/code.r
 
## Retrospective Summary
Here's what went well:
- The team worked well together
- Always were able to find a time we could meet even with busy schedules.
- Assignments were completed on time (we were given one extra week due to delays).

Here's what we'd like to improve:
- Start work earlier. Some things were finished last minute, but there was improvement toward the end.
- Did not create issues for unfinished work.

Here are changes we plan to implement in the next sprint:
- Continue to work on things before they are due so that there is not time crunch.
- Communicate more often and make sure everybody knows what they should be doing.
- Create new issues when things are realized and need to be started not after.
