
# PsychClinic-Webapp

This repository contains code and documents for Capstone Project Psychclinic WebApp.

## Project summary
The Washington State University Psychology Clinic uses a survey tool called Qualtrics to conduct a personality assessment survey. Participants can take the survey and then receive back a PowerPoint that contains graphs/tables/figures created using the data collected from the survey. Currently, the Qualtrics survey is unable to present the data back to participants in forms other than strictly text. Since purely text can be extremely confusing for participants, at the end of the survey the data is sent to the Psychology Clinic and the user is not presented any information at the time. The data is stored in a CSV file format. That data is then manually run using a program developed by Aninda, a colleague of Walter Scott, and the result of the program is a PowerPoint with graphs and figures that represent the data visually. This is a solution for the time being, however, it can take a couple weeks for the participants to receive the data back. The objective is to improve upon the Qualtrics survey so that the figures and graphs, created using the data, are automatically presented to participants after the completion of the survey. Along with improving the current form of the survey, Team Bluebirds has been tasked with designing the improvements in such a way that it does not require an extensive background in coding to maintain and to add additional functionality in the future.

Team Bluebirds has done research and discovered that although Qualtrics is only able to present the data collected in the survey in a text only form, Qualtrics is able to utilize languages such as Python and JavaScript which will allow the creation of graphs/figures inside the survey. With this information, it was decided that Python will be the primary language since it is a relatively simple language, but it also has access to many additional libraries and frameworks that will assist in handling the data and creating the figures/graphs. Python is a simple and easy to learn language because it does not have extremely complex syntax. This makes Python perfect for this operation since it is not too complex and has the ability to handle the data and create the output needed. The libraries and frameworks that we have determined the most valuable to this project are flask, django and pandas.


### One-sentence description of the project

We will take data from a qualrics survey and immediately display the proccessed data using visual aids to the survey participant.

### Additional information about the project

TODO: Write a compelling/creative/informative project description / summary

## Installation

### Prerequisites

- Have a working internet connection
- A browser capable of supporting qualtrics

### Add-ons

TODO: List which add-ons are included in the project, and the purpose each add-on serves in your app.

### Installation Steps

TODO: Describe the installation process (making sure you mention `bundle install`).
Instructions need to be such that a user can just copy/paste the commands to get things set up and running. 


## Functionality

TODO: Write usage instructions. Structuring it as a walkthrough can help structure this section,
and showcase your features.


## Known Problems

TODO: Describe any known issues, bugs, odd behaviors or code smells. 
Provide steps to reproduce the problem and/or name a file or a function where the problem lives.


## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## Additional Documentation

Sprint report 1 - https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/main/sprint_report.md

## License

https://github.com/WSUCptSCapstone-Fall2022Spring2023/psychclinic-webapp/blob/main/LICENSE.txt