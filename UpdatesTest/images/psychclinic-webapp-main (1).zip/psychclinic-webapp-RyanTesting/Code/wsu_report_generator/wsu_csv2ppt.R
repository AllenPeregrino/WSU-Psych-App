# Contributor - Aninda Roy

# WSU - Personality Assessment - Report Generator
#
# January-February 2022
#
# inputs: 
#   a. CSV file per participant with list of fields and data
#   b. PowerPoint template with placeholders [field]
# outputs:
#   a. a set of PowerPoint files, one per participant
#

# *** Make sure to INSTALL the required packages ***
#
#     Required:
#       xml2
#       stringr
#       zip 

# running this line sets the working folder to the folder this file is in
#
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# this loads the required support functions - run once
#
source("wsu_pptgen.R")

#*************************************
# Run PowerPoint Generator
#*************************************
run_report_generator <- function() {
  
  if (!dir.exists("outputs")) dir.create("outputs")
  if (!dir.exists("qualtrics")) stop("missing qualtrics folder")
  if (!dir.exists("inputs")) stop("missing inputs folder")
  if (!dir.exists("config")) stop("missing config folder")
  
  # convert the qualtrics file(s) to our data csv format
  # place the qualtrics csv files in the /qualtrics folder
  # the new csv files will be saved to the /inputs folder
  #
  fn.qual <- list.files("qualtrics","*.csv")
  if (length(fn.qual)==0) {
      print("warning: no qualtrics file")
    } else {
      print("parsing qualtrics file(s)")
      for (i in 1:length(fn.qual)) {
        tryCatch({
          qual2csv(fn.qual[i])
          print(paste("successful: ",fn.qual[i]))
        },error=function(e){
          message("failed:",fn.qual[i],"\nerror: ",e)
        })
      }
    }
  
  # use the most recent pptx file as the template
  fn.template = file.info(list.files("config","*.pptx",full.names = T))
  if (nrow(fn.template)==0) stop("missing powerpoint template in config folder")
  fn.template = rownames(fn.template[order(fn.template$mtime,decreasing = T),])[1] # most recent
  print(paste("using powerpoint template: ",fn.template))
  
  # process all the csv files in the inputs folder
  fn.csv      <- list.files("inputs","*.csv")
  fn.dat      <- paste0("inputs/", fn.csv)
  fn.ppt      <- paste0("outputs/", gsub("\\.csv",".pptx", fn.csv))
  
  print(paste("using template: ",fn.template," #files:", length(fn.csv)))
  
  if (length(fn.csv)>0) {
    for (i in 1:length(fn.csv)) {
      tryCatch({
        csv2ppt(fn.template, fn.dat[i], fn.ppt[i])
        print(paste("successful: ",fn.csv[i]))
        },error=function(e){
        message("failed:",fn.csv[i],"\nerror: ",e)
      })
    }
  }
}

run_report_generator()

