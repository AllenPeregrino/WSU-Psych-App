# Contributor - Aninda Roy

# WSU - Personality Assessment - Report Generator
#
# January 2022
# REVISED: 20-APR-2022
#
library(xml2)
library(stringr)
library(zip) 
# the "zip" package overrides the default utils::zip
# zip::zip works on Windows and Mac
# because it includes the necessary OS specific zip library
# utils::unzip is used below because it has a 'look ahead' feature
# that zip::unzip lacks

# library(openxlsx)

# scale conversions
# For all other Goal and Moral Standard Variables:
#  1.0-2.00 = very low        3.5-4.49 = average        6.00-7.00 = very high
#  2.01-2.99 = low            4.5-4.99 = high average
#  3.00-3.49 = low average    5.0-5.99 = high

brk <- c(1,2,3,3.5,4.5,5,6,7.1)
lab <- c("very low","low","low average","average","high average","high","very high")
score_to_scale1 <- function(x) sprintf("%s(%g)",cut(x,breaks=brk,labels=lab,right=F),x)

# For Goal and Moral Standard Thinking:
#  0-1.49   = very low        3.00-3.49 = average         5.00-6.00 = very high
# 1.50-2.49 = low             3.50-3.99 = high average
# 2.50-2.99 = low average     4.00-4.99 = high
brk2 <- c(0,1.5,2.5,3,3.5,4,5,7.1)
score_to_scale2 <- function(x) sprintf("%s(%g)",cut(x,breaks=brk2,labels=lab,right=F),x)

# Scale Interpretation Score categories:
# 1.0-1.49 = very low         2.5-3.5 = average           4.49-5.0 = very high
# 1.5-1.99 = low              3.51-3.99 = high average
# 2.0-2.49 = low average      4.0-4.49 = high
brk3 <- c(1,1.5,2,2.5,3.5,4,4.5,5.1)
score_to_scale3 <- function(x) sprintf("%s\n(%g)",cut(x,breaks=brk3,labels=lab,right=F),x)


fields_convert <- read.csv("config/fields_convert.csv")

convert_scale <- function(fields_map) {
  for (i in 1:nrow(fields_map)) {
    dat <- suppressWarnings(as.numeric(trimws(fields_map$data[i])))
    if (!is.na(dat)) {
      convert_type <- fields_convert$convert[fields_convert$field==fields_map$field[i]]
      if (length(convert_type)>0) {
        if (convert_type>0) {
          if (convert_type==1)
            fields_map$data[i] <- score_to_scale1(dat) # type 1 scale descriptor
          else if (convert_type==2)
            fields_map$data[i] <- score_to_scale2(dat) # type 2 scale descriptor
          else
            fields_map$data[i] <- score_to_scale3(dat) # type 3 scale descriptor
        }
      }
    }
  }

  return(fields_map$data)
}


#
# helper function: replace fields with mapped strings
#
replace_fields <- function(txt,dbug=F) {
  # Example: txt = "What is your role? [RSSMName2] in department [RSSMRole2] "
  
  match <- str_extract_all(txt, "\\[[^\\[\\]]+\\]" )[[1]]
  if (dbug==T) message("match: ",paste(match,collapse = " | "))
  
  if (length(match)==0)
    return(txt)
  else {
    s <- str_extract(match, "[^\\[].*[^\\]]")
    # Example: s = c("RSSMName2", "RSSMName2")

    if (dbug==T) message("s: ",paste(s,collapse = " | "))
    
    for (i in 1:length(s)) {
      s1 <- s[i]
      f <- fields_map$data[fields_map$field==tolower(s1)]
      if (length(f)==0) {
        # skip
      }
      else {
        if (dbug==T) message("replacing: >",s1,"<->",f,"<")
        txt <- str_replace(txt, paste0("\\[", s1, "\\]",collapse = ""), f)
      }
    }
    return(txt)
  }
}

#=============================
# generate ppt from template
#=============================

csv2ppt <- function(fn.template, fn.dat, fn.ppt) {

  # this is a *** global *** accessed by replace_fields function
  fields_map       <<- read.csv(fn.dat)
  fields_map$field <<- tolower(fields_map$field)
  fields_map$data  <<- convert_scale(fields_map)
  
  # inspect template
  zipdat     <- utils::unzip(fn.template, files = NULL, list = TRUE, overwrite = TRUE)
  xml_files  <- grep("\\.xml$",zipdat$Name,value=T)
  slide_names <- grep("ppt/slides/",xml_files,value=T)
  # message("# of slides: ",length(slide_names))

  # extract template
  zipdat <- utils::unzip(fn.template, files = NULL, exdir = "deckfiles", overwrite = TRUE)
  curdir <- getwd()
  setwd("deckfiles")
  
  for (s in slide_names) {
    # open slide
    sldxml <- read_xml(s)
    
    # find & replace text
    xn <- xml_find_all(sldxml,"//a:t") # xml nodes containing text
    txt <- sapply(xn,xml_text)
    
    for (i in 1:length(txt)) {
      xml_text(xn[[i]]) <- replace_fields(txt[i])
    }
    
    # update xml file
    write_xml(sldxml,s)
  }
  
  # compile new file
  # message("zip target: ", paste0("../",fn.ppt))

  # use zip from the "zip" package
  zip(
    zipfile = paste0("../",fn.ppt),
    files = list.files(),
    recurse = TRUE,
    include_directories = TRUE,
    root = ".",
    mode = "mirror"
  )
  
  # cleanup
  setwd(curdir)
  unlink("./deckfiles",recursive = T)
  
  return(fn.ppt)
}

#********************
# Qualtrics CSV fixer
#********************

# Be sure to setwd() to the wsu_report_generator folder (above)

qual2csv <- function(fn) {
  
  # read & transpose the qualtrics csv file
  #
  dat <<- read.csv(paste0("qualtrics/",fn))
  dat <<- as.data.frame(t(as.matrix(dat)))

  # keep only the 'data' rows toward the end of the file starting with SC0
  #
  s <-    which(rownames(dat)=="SC0")
  e <-    nrow(dat)
  rid <-  which(rownames(dat)=="ResponseId")
  dat <<- dat[c(rid,s:e),]

  # how many data columns (# of survey respondents)
  #
  if (which(grepl("\\{", c(dat[1,]) ))!=2) message("unexpected data in qualtrics file")
  nsurvey <- ncol(dat)-2
  
  for (i in 1:nsurvey) {
    
    d1 <- dat[,c(1,2+i)] # take one survey respondent at a time
    
    # rename the columns to be 'field' and 'data'
    #
    colnames(d1) <- c("field","data")
    d1$field <- rownames(d1)

    # write the new file into the inputs folder
    #
    write.csv(d1, paste0("inputs/",i,"-",fn), row.names = F)
  }
}

