import math

def get_sort(data):
    #BIS_BAS: bis, basRR, basD, basFS
    temperament = [0]*4
    #PACI_Revised: gThinking, gSatisfaction, gSelfEfficacy, gIntrinsicMotivation, gApproachOrientation, gGrowthMindset, gLevelConflict
    selfRegulation = [0]*7
    #RSSM: relatednessSatisfaction, controlSatisfaction, selfEsteemFrustration, autonomyFrustration
    beliefsRSSM = [0]*4
    #CSIP: domineering, selfCentered, distantCold, sociallyInhibited, nonassertive, exploitable, selfSacrificing, intrusive
    beliefsCSIP = [0]*8

    final = ""
    all = []
    temperament = [data['Temperament']['BIS'], data['Temperament']['BAS-RR'], data['Temperament']['BAS-D'], data['Temperament']['BAS-FS']]
    tFactors = ["BIS", "BAS: Reward Responsiveness", "BAS: Drive", "BAS: Fun Seeking"]
    selfRegulation = [data['Goals']['GoalThink'], data['Goals']['GoalSatis'], data['Goals']['GoalEfficacy'], data['Goals']['GoalIntrinsic'], data['Goals']['GoalApproach'], data['Goals']['GoalGrowth'], data['Goals']['GoalConflict']]
    srFactors = ["Goal Thinking", "Goal Satisfaction", "Goal Self-Efficacy", "Goal Intrinsic Motivation", "Goal Approach Orientation", "Goal Growth Mindset", "Goal Level of Conflict"]
    beliefsRSSM = [data['RSSM']['RssmRelateSatis'], data['RSSM']['RssmControlSatis'], data['RSSM']['RssmEsteemFrus'], data['RSSM']['RssmAutoFrus']]
    rssmFactors = ["Relatedness Satisfaction", "Control Satisfaction", "Self-Esteem Frustration", "Autonomy Frustration"]
    beliefsCSIP = [data['RadarRSSM']['RadarRSSMDominantIPS'], data['RadarRSSM']['RadarRSSMDominDistantIPS'], data['RadarRSSM']['RadarRSSMDistantIPS'], data['RadarRSSM']['RadarRSSMYieldDistantIPS'], data['RadarRSSM']['RadarRSSMYieldIPS'], data['RadarRSSM']['RadarRSSMYieldFriendIPS'], data['RadarRSSM']['RadarRSSMFriendIPS'], data['RadarRSSM']['RadarRSSMDominFriendIPS']]
    csipFactors = ["Domineering", "Self-Centered", "Distant/Cold", "Socially Inhibited", "Nonassertive", "Exploitable", "Self-Sacrificing", "Intrusive"]

    temperament = list(map(lambda x:float(x), temperament))
    temperament = list(map(lambda x:2 if math.isnan(x) else x, temperament))
    selfRegulation = list(map(lambda x:list(map(lambda y:float(y), x)), selfRegulation))
    selfRegulation = list(map(lambda x:list(map(lambda y:3 if math.isnan(y) else y, x)), selfRegulation))
    beliefsRSSM = list(map(lambda x:list(map(lambda y:float(y), x)), beliefsRSSM))
    beliefsRSSM = list(map(lambda x:list(map(lambda y:3 if math.isnan(y) else y, x)), beliefsRSSM))
    beliefsCSIP = list(map(lambda x:list(map(lambda y:float(y), x)), beliefsCSIP))
    beliefsCSIP = list(map(lambda x:list(map(lambda y:3 if math.isnan(y) else y, x)), beliefsCSIP))

    #Temperament
    tVals = []
    tTypes = []
    #Acceptance and commitment therapy (Hayes, Stroshahl, & Wilson, 1999)
    act = temperament[0]*.5 + (4 - temperament[2])*.5
    tVals.append(act)
    tTypes.append("Acceptance and commitment therapy")
    #Mindfulness Practice (Dimidjian & Linehan, 2009*; Kabat-Zinn, 1990)
    mp = temperament[0]*.3 + (4 - temperament[1])*.4 + (4 - temperament[2])*.3
    tVals.append(mp)
    tTypes.append("Mindfulness Practice")
    #Relaxation Training (Ferguson et al., 2009*)
    rt = temperament[0]*1.0
    tVals.append(rt)
    tTypes.append("Relaxation Training")
    #Emotion Regulation Interventions for Anger (Donohue et al., 2009*)
    eria = temperament[0]*.3 + (4 - temperament[1])*.35 + (4 - temperament[2])*.35
    tVals.append(eria)
    tTypes.append("Emotion Regulation Interventions for Anger")
    #Interoceptive Exposure (Barlow, 2001; see Forsyth et al., 2009*)
    ie = temperament[0]*1.0
    tVals.append(ie)
    tTypes.append("Interoceptive Exposure")
    #Live (In Vivo) Exposure (Hazlett-Stevens & Craske, 2009*)
    le = temperament[0]*1.0
    tVals.append(le)
    tTypes.append("Live (In Vivo) Exposure")
    #Fruzzetti et al. (2009) “Emotion Regulation”
    er = temperament[0]*.35 + (4 - temperament[1])*.35 + (4 - temperament[2])*.15 + (4 - temperament[2])*.15
    tVals.append(er)
    tTypes.append("Emotion Regulation")

    #calculate ranking
    final += "Temperament: \n"
    tTemp = tVals.copy()

    if max(tTemp) <= 2.2:
        final += "No significant treatment \nrecommendations\n"
    else:
        for i in range (1, 3):
            idx = tTemp.index(max(tTemp))
            tTemp[idx] = -1
            text = "%d. %s\n" % (i, tTypes[idx])
            final += text

        tSignificant = [z for z in temperament if (z > 3 or z < 1)]
        if len(tSignificant) > 0:
            final += "Significant Factor(s) of \nInterest: \n"
        for i, s in enumerate(temperament):
            if s < 1:
                final += "- " + tFactors[i] + " (Very Low)" + "\n"
            elif s > 3:
                final += "- " + tFactors[i] + " (Very High)" + "\n"
    all.append(final)

    cleanedList = [x for x in data['GoalDescription'] if str(x) != 'nan']
    for sr in selfRegulation:
        o = sum(sr) / float(len(sr))
        sr.insert(0, o)
    srTexts = []
    srOrder = []

    for x in range(0, len(cleanedList)+1):
        #Self-Regulation
        srVals = []
        srTypes = []
        currSR = ""

        #Schema change therapy (Newman, 2009*; Young, Klosko, & Weishaar, 2000)
        sct = (8 - selfRegulation[1][x])*.4 + (8 - selfRegulation[2][x])*.3 + (8 - selfRegulation[4][x])*.3
        srVals.append(sct)
        srTypes.append("Schema change therapy")
        #Situational Analysis
        sa = (8 - selfRegulation[3][x])*.33 + (8 - selfRegulation[5][x])*.33 + selfRegulation[6][x]*.34
        srVals.append(sa)
        srTypes.append("Situational Analysis")
        #Cognitive Restructuring Techniques (J. Beck, 1995; Riso, du Toit, Stein, & Young, 2007)
        crt = (8 - selfRegulation[0][x])*.2 + (8 - selfRegulation[2][x])*.3 + (8 - selfRegulation[3][x])*.2 + (8 - selfRegulation[4][x])*.3
        srVals.append(crt)
        srTypes.append("Cognitive Restructuring Techniques")
        #Behavioral tests of negative cognitions (Dobson & Hamilton, 2009)
        btnc = (8 - selfRegulation[1][x])*.2 + (8 - selfRegulation[2][x])*.4 + selfRegulation[6][x]*.4
        srVals.append(btnc)
        srTypes.append("Behavioral tests of negative cognitions")
        #Interpersonal Psychotherapy
        ip = (8 - selfRegulation[2][x])*.32 + (8 - selfRegulation[3][x])*.36 + (8 - selfRegulation[5][x])*.32
        srVals.append(ip)
        srTypes.append("Interpersonal Psychotherapy")

        srTemp = srVals.copy()
        #calculate ranking
        if x == 0:
            final = "Self-Regulation: Overall\n"
        else:
            currSR = "Self-Regulation: Goal %d\n" % (x)
            srOrder.append(max(srTemp))

        if max(srTemp) <= 3.85:
            if x == 0:
                final += "No significant treatment \nrecommendations\n"
            else:
                currSR += "No significant treatment \nrecommendations\n"
        else:
            for i in range (1, 3):
                idx = srTemp.index(max(srTemp))
                srTemp[idx] = -1
                text = "%d. %s\n" % (i, srTypes[idx])
                if x == 0:
                    final += text
                else:
                    currSR += text

            currScores = []
            for y in selfRegulation:
                currScores.append(y[x])
            srSignificant = [z for z in currScores if (z > 5.5 or z < 2.5)]
            if len(srSignificant) > 0:
                currSR += "Significant Factor(s) of \nInterest: \n"
            for i, s in enumerate(currScores):
                if s > 5.5:
                    currSR += "- " + srFactors[i] + " (Very High)" + "\n"
                if s < 2.5:
                    currSR += "- " + srFactors[i] + " (Very Low)" + "\n"

        if x != 0:
            srTexts.append(currSR)
        else:
            all.append(final)

    for i in range (1, 5):
        idx = srOrder.index(max(srOrder))
        srOrder[idx] = -1
        all.append("#"+ str(i) + " " + srTexts[idx])


    for csip in beliefsCSIP:
        o = sum(csip) / float(len(csip))
        csip.insert(0, o)
    namesRSSM = list(data['RSSMNames'].values())
    bTexts = []
    bOrder = []

    for x in range(0, len(namesRSSM)):
        #Beliefs
        bVals = []
        bTypes = []
        currB = ""

        #Motivational Interviewing (Levensky et al., 2009*; Miller & Rollnick, 2002)
        mi = (6 - beliefsRSSM[1][x])*.45 + beliefsRSSM[3][x]*.55
        mi += (3 - beliefsCSIP[1][x])*.4 + beliefsCSIP[4][x]*.3 + beliefsCSIP[5][x]*.3
        bVals.append(mi)
        bTypes.append("Motivational Interviewing")
        #Value Clarification (Twohig  & Crosby, 2009*)
        vc = (6 - beliefsRSSM[1][x])*.2 + (6 - beliefsRSSM[2][x])*.4 + beliefsRSSM[3][x]*.4
        vc += (3 - beliefsCSIP[0][x])*.31 + beliefsCSIP[4][x]*.23 + beliefsCSIP[5][x]*.23 + beliefsCSIP[6][x]*.23
        bVals.append(vc)
        bTypes.append("Value Clarification")
        #Guided Mastery Therapy (Bandura, 1997; Scott & Cervone, 2009*; Williams, 1992)
        gmt = (6 - beliefsRSSM[0][x])*.4 + (6 - beliefsRSSM[2][x])*.6
        gmt += beliefsCSIP[3][x]*.55 + beliefsCSIP[7][x]*.45
        bVals.append(gmt)
        bTypes.append("Guided Mastery Therapy")
        #Self-monitoring (Humphreys et al., 2009*)
        sm = (6 - beliefsRSSM[1][x])*.4 + beliefsRSSM[3][x]*.6
        sm += beliefsCSIP[4][x]*.5 + beliefsCSIP[5][x]*.5
        bVals.append(sm)
        bTypes.append("Self-monitoring")
        #Self-management therapy (Rehm, 1990; Rehm & Adams, 2009*)
        smt = (6 - beliefsRSSM[1][x])*.5 + (6 - beliefsRSSM[2][x])*.5
        smt += beliefsCSIP[2][x]*.34 + beliefsCSIP[3][x]*.33 + beliefsCSIP[6][x]*.33
        bVals.append(smt)
        bTypes.append("Self-management therapy")

        #calculate ranking
        bTemp = bVals.copy()
        if x == 0:
            final = "Beliefs: Overall\n"
        else:
            currB = "Beliefs: Self-with-%s\n" % (namesRSSM[x])
            bOrder.append(max(bTemp))

        if max(bTemp) <= 4.4:
            if x == 0:
               final += "No significant treatment \nrecommendations\n"
            else:
                currB += "No significant treatment \nrecommendations\n"
        else:
            for i in range (1, 3):
                idx = bTemp.index(max(bTemp))
                bTemp[idx] = -1
                text = "%d. %s\n" % (i, bTypes[idx])
                if x == 0:
                    final += text
                else:
                    currB += text

            currScoresRSSM = []
            currScoresCSIP = []
            for y in beliefsRSSM:
                currScoresRSSM.append(y[x])
            for y in beliefsCSIP:
                currScoresCSIP.append(y[x])
            bSignificantRSSM = [z for z in currScoresRSSM if (z > 4 or z < 2)]
            bSignificantCSIP = [z for z in currScoresCSIP if (z > 2 or z < 1)]
            if len(bSignificantRSSM) > 0 or len(bSignificantCSIP) > 0:
                currB += "Significant Factor(s) of \nInterest: \n"
            for i, s in enumerate(currScoresRSSM):
                if s > 4:
                    currB += "- " + rssmFactors[i] + " (Very High)" + "\n"
                elif s < 2:
                    currB += "- " + rssmFactors[i] + " (Very Low)" + "\n"
            for i, s in enumerate(currScoresCSIP):
                if s > 2:
                    currB += "- " + csipFactors[i] + " (Very High)" + "\n"
                elif s < 1:
                    currB += "- " + csipFactors[i] + " (Very Low)" + "\n"

        if x != 0:
            bTexts.append(currB)
        else:
            all.append(final)

    for i in range (1, 5):
        idx = bOrder.index(max(bOrder))
        bOrder[idx] = -1
        all.append("#"+ str(i) + " " + bTexts[idx])

    return all

