# This file is for deployment, providing PythonAnywhere (or any WSGI server) with the entry point to start your app.

# This imports the Flask app instance from psychclinic.py
#   -psychclinic.py contain's application's core logic
from psychclinic import app